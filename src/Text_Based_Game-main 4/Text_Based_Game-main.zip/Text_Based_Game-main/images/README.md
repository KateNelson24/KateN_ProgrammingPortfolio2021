![CryptidClubUML](https://github.com/dizzycake/Text_Based_Game/blob/main/images/Cryptid%20Club.png)

![Nessie (1)](https://user-images.githubusercontent.com/80906139/116938467-10798200-ac28-11eb-8f0f-17dc9be48494.png)
![MothMan (1)](https://user-images.githubusercontent.com/80906139/116938531-22f3bb80-ac28-11eb-95e4-2747cc4ff4f3.png)
![Big Foot](https://user-images.githubusercontent.com/80906139/117169599-767c1b80-ad86-11eb-8add-a658a540fbb0.png)
![Yeti](https://user-images.githubusercontent.com/80906139/117547112-1b972e00-afeb-11eb-93d2-849c7c2fc722.png)

![Lampost](https://user-images.githubusercontent.com/80906139/117547381-8bf27f00-afec-11eb-9353-9e2dbd3a50a1.png)
![WaterTank](https://user-images.githubusercontent.com/80906139/117547652-dfb19800-afed-11eb-8d61-caa16e71b5bf.png)
![Photo](https://user-images.githubusercontent.com/80906139/117548165-af1f2d80-aff0-11eb-9519-0c3fc81d846c.png)
![Cocoa](https://user-images.githubusercontent.com/80906139/117548472-74b69000-aff2-11eb-977f-760c2ecb18a9.png)
![Snow](https://user-images.githubusercontent.com/80906139/117549370-4be4c980-aff7-11eb-96a7-20d17d764f6b.png)
![Letter](https://user-images.githubusercontent.com/80906139/119505880-a174e200-bd2a-11eb-80c4-b7f1433df7de.png)








