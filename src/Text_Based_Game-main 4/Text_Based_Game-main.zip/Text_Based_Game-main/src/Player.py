class Player:
  def __init__(self, name, age, image):
    self.name = name
    self.age = age
    self.image = image

p1 = Player("John", 36, 'graphic')

print(p1.name)
print(p1.age)
print(p1.image)
