class Chatbox:
  def __init__(self, hi, book, read):
    self.name = hi
    self.age = book
    self.image = read
    
  def draw(): 
    pass
  
  def keyTyped(1, 2, 3):
    
